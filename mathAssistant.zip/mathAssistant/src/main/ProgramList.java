package main;

public enum ProgramList {
    CALCULATOR, // 0
    GRAPH_EDITOR, // 1
    NOTES // 2
}
