# Math Assistant

Math Assistant is a hobby project aimed at providing various mathematical tools and utilities in
an easy-to-use interface. It's obviously nothing serious and I am just trying to improve my 
programming/math skills, so if you are looking for an actual math tool look somewhere else.